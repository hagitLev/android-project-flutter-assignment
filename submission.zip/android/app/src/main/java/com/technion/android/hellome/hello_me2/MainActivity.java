package com.technion.android.hellome.hello_me2;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
